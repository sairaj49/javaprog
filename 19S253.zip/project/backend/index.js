const express = require("express");
const cors = require("cors");
const mongodb = require("mongodb");
const { ObjectID } = require("bson");
const app = express();
const port = 5000;
app.use(express.json());
app.use(cors());
const MongoClient = mongodb.MongoClient;
const connectionURL = "mongodb://localhost:27017";
const databaseName = "college";
const collection = "cars";

const ObjectId = mongodb.ObjectId;

app.get("/api/cars", (req, res) => {
  MongoClient.connect(
    connectionURL,
    { useNewUrlParser: true },
    (error, client) => {
      if (error) {
        return console.log("Not Connected to data");
      }

      const db = client.db(databaseName);
      const Output = db
        .collection("cars")
        .find()
        .toArray(function (err, results) {
          console.log(results);
          res.send(results);
        });
    }
  );
});

app.post("/api/car", (req, res) => {
  MongoClient.connect(
    connectionURL,
    { useNewUrlParser: true },
    (error, client) => {
      if (error) {
        return console.log("Not Connected to data");
      }

      const db = client.db(databaseName);

      db.collection("cars").insertOne({
        carName: req.body.carName,
        carColour: req.body.carColour,
        carType: req.body.carType,
        carYear: req.body.carYear,
      });

      const posted = [{ posted: "yes" }];
      res.send(posted);
    }
  );
});

app.delete("/api/delete/:id", (req, res) => {
  const id = req.params.id;

  console.log(req.params.id);

  MongoClient.connect(
    connectionURL,
    { useNewUrlParser: true },
    (err, client) => {
      if (err) {
        return console.log(err);
      }

      const db = client.db(databaseName);
      db.collection(collection)
        .deleteOne({
          _id: ObjectId(id),
        })
        .then((result) => {
          res.send(result);
        });
    }
  );
});

app.put("/api/update", (req, res) => {
  const id = req.body.id;
  const carName = req.body.carName;
  const carColour = req.body.carColour;
  const carDuration = req.body.carDuration;
  const carType = req.body.carType;
  MongoClient.connect(
    connectionURL,
    { useNewUrlParser: true },
    (error, client) => {
      if (error) {
        return console.log("Not Connected to data");
      }

      const db = client.db(databaseName);

      db.collection(collection)
        .updateOne(
          { _id: ObjectID(id) },
          {
            $set: {
              carName: carName,
              carDuration: carDuration,
              carColour: carColour,
              cartype: carType,
            },
          }
        )
        .then((result) => {
          res.send(result);
        });
    }
  );
});

app.listen(port, () => console.log("listening on port ${port}!"));
