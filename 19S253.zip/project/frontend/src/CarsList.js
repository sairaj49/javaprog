import React from "react";
import axios from "axios";

class CarList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isUpdate: false,
      CarList: [],
      carName: null,
      carColour: null,
      carType: null,
      carYear: null,
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:5000/api/cars")
      .then((res) => {
        const carsList = res.data;
        this.setState({ CarList: carsList });
      })
      .catch((error) => {
        console.log("ERROR");
      });
  }

  Delete(id) {
    axios
      .delete(`http://localhost:5000/api/delete/${id}`)
      .then((res) => {
        window.location.reload(false);
        console.log(res);
      })
      .catch((error) => {
        console.log(error);
      });
  }

  Update(id) {
    const data = {
      id: id,
      carName: this.state.carName,
      carColour: this.state.carColour,
      carType: this.state.carType,
      carYear: this.state.carYear,
    };
    console.log(data);

    axios
      .put("http://localhost:5000/api/update", data)
      .then((res) => {
        window.location.reload(false);
        console.log(res);
      })
      .catch((error) => {
        console.log("ERROR");
      });
  }

  onInputChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  render() {
    return (
      <div>
        <p>Cars</p>
        <table border="1">
          <tr>
            <td>name</td>
            <td>color</td>
            <td>type</td>
            <td>year</td>
          </tr>
          {this.state.CarList.map((car) => {
            return (
              <tr>
                <td>{car.carName}</td>
                <td>{car.carColour}</td>
                <td>{car.carType}</td>
                <td>{car.carYear}</td>

                <button onClick={() => this.Delete(car._id)}>Delete</button>

                <button
                  onClick={() =>
                    this.setState({
                      isUpdate: true,
                      id: car._id,
                      carName: car.carName,
                      carColour: car.carColour,
                      carType: car.carType,
                      carYear: car.carYear,
                    })
                  }
                >
                  Update
                </button>
              </tr>
            );
          })}
        </table>

        <br />
        <br />
        <br />

        {this.state.isUpdate ? (
          <div>
            <h3>ENTER NEW DETAILS</h3>

            <input
              name="carName"
              placeholder="carName"
              value={this.state.carName}
              onChange={this.onInputChange}
            />

            <input
              name="carColour"
              placeholder="carColour"
              value={this.state.carColour}
              onChange={this.onInputChange}
            />

            <input
              name="carYear"
              placeholder="carYear"
              value={this.state.carYear}
              onChange={this.onInputChange}
            />

            <input
              type="radio"
              name="carType"
              placeholder="CarType"
              value={this.state.carType}
              onChange={this.onInputChange}
            />
            <label>Petrol</label>

            <input
              type="radio"
              name="carType"
              placeholder="CarType"
              value={this.state.carType}
              onChange={this.onInputChange}
            />
            <label>Diesel</label>

            <br />
            <br />

            <button onClick={() => this.Update(this.state.id)}>
              Update cars
            </button>
          </div>
        ) : (
          <div></div>
        )}
      </div>
    );
  }
}

export default CarList;
