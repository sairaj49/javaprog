import logo from "./logo.svg";
import "./App.css";
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import NavBar from "./NavBar";
import CreateCars from "./CreateCars";
import CarList from "./CarsList";

function App() {
  return (
    <BrowserRouter>
      <div>
        <NavBar />
        <Routes>
          <Route exact path="/api/car" element={<CreateCars />} />
          <Route exact path="/api/cars" element={<CarList />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
