import React from "react";
import { Link, NavLink } from "react-router-dom";

function NavBar() {
  return (
    <nav>
      <div>
        <Link to="/"> HOME</Link>
        <ul>
          <li>
            <NavLink to="/api/car">Create Cars</NavLink>
          </li>
          <li>
            <NavLink to="/api/cars">List of Cars</NavLink>
          </li>
        </ul>
      </div>
    </nav>
  );
}
export default NavBar;
