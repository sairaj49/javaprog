import React from "react";
import axios from "axios";
class CreateCars extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      carName: null,
      carColour: null,
      carType: null,
      carYear: null,
    };
  }
  onSubmitHandler = (event) => {
    const data = {
      carName: this.state.carName,
      carColour: this.state.carColour,
      carType: this.state.carType,
      carYear: this.state.carYear,
    };
    console.log(this.state);
    axios
      .post("http://localhost:5000/api/car", data)
      .then((res) => console.log(res));
    event.preventDefault();
  };
  onChangeHandler = (event) => {
    console.log(event.target.name);
    this.setState({ [event.target.name]: event.target.value });
  };
  render() {
    return (
      <div>
        <form onSubmit={this.onSubmitHandler}>
          <input
            name="carName"
            placeholder="carName"
            value={this.state.carName}
            onChange={this.onChangeHandler}
          />

          <input
            name="carColour"
            placeholder="carColour"
            value={this.state.carColour}
            onChange={this.onChangeHandler}
          />

          <input
            name="carYear"
            placeholder="carYear"
            value={this.state.carYear}
            onChange={this.onChangeHandler}
          />

          <input
            type="radio"
            name="carType"
            placeholder="CarType"
            value={"petrol"}
            onChange={this.onChangeHandler}
          />
          <label>Petrol</label>

          <input
            type="radio"
            name="carType"
            placeholder="CarType"
            value={"diesel"}
            onChange={this.onChangeHandler}
          />
          <label>Diesel</label>
          <button type="=SUBMIT">Create Cars</button>
        </form>
      </div>
    );
  }
}
export default CreateCars;
